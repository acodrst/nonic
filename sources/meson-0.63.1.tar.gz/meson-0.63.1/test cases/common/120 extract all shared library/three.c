#include"extractor.h"

int func3(void) {
    return 3;
}
